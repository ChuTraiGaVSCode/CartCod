<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/commons/taglib.jsp"%>
<c:set var="ctx" value="${pageContext.request.contextPath}" />

<style>
.video-detail {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 15px;
}

.video-detail-poster {
    flex: 1 1 300px;
    max-width: 400px; 
}

.video-detail-poster img {
    width: 100%;
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    object-fit: cover;
    display: block;
}

.video-detail-info {
    flex: 2 1 300px;
}

.video-description {
    white-space: pre-line;
    color: #555;
}
</style>

<div class="card" style="padding: 20px;">
	<p><a href="${ctx}/videos#cat-${video.categoryId}">&laquo; Quay lại danh sách <c:out value="${video.categoryName}"/></a></p>

	<div class="video-detail">
		<div class="video-detail-poster">
			<img alt="<c:out value='${video.title}'/>"
				src="${ctx}/image?fname=<c:out value='${video.poster}'/>"
				onerror="this.onerror=null;this.src='';this.classList.add('video-poster-empty');">
		</div>
		<div class="video-detail-info">
			<p><strong>Tiêu đề:</strong> <c:out value="${video.title}"/></p>
			<p><strong>Mã video:</strong> <c:out value="${video.videoId}"/></p>
			<p><strong>Category name:</strong> <c:out value="${video.categoryName}"/></p>
			<p><strong>View:</strong> ${video.views}</p>
			<p>
				<span class="badge badge-user">Share(${video.shareCount})</span>
				<span class="badge badge-on">Like(${video.likeCount})</span>
			</p>
			<p><strong>Mô tả:</strong></p>
			<p class="video-description"><c:out value="${video.description}"/></p>
			<c:if test="${sessionScope.account.admin}">
				<p><a class="btn btn-primary" href="${ctx}/admin/video/edit?id=<c:out value='${video.videoId}'/>">Chỉnh sửa video</a></p>
			</c:if>
		</div>
	</div>
</div>